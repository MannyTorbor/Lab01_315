#include "SortedLinkedListDict.hpp"

SortedLinkedListDict::SortedLinkedListDict() : head(nullptr) {}

SortedLinkedListDict::~SortedLinkedListDict() {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void SortedLinkedListDict::insert(int key) {
    Node* newNode = new Node;
    newNode->data = key;
    newNode->next = nullptr;
    // Need this so that we can insert at the front if the list is empty or the key is smaller than the head.
    if (head == nullptr || head->data >= key) {
        newNode->next = head;
        head = newNode;
        return;
    }
    // Need this so we can find the correct position to insert
    Node* current = head;
    while (current->next != nullptr && current->next->data < key) {
        current = current->next;
    }

    newNode->next = current->next;
    current->next = newNode;
}
bool SortedLinkedListDict::lookup(int key) const {
    Node* current = head;
    while (current != nullptr) {
        if (current->data == key) {
            return true;
        }
        //Using break so that we exit when the list is sorted
        if (current->data > key){
            break;
        }
        current = current->next;
    }
    return false;
}
void SortedLinkedListDict::remove(int key) {
    Node* current = head;
    Node* prev = nullptr;

    while (current != nullptr) {
        if (current->data == key) {
            if (prev != nullptr) {
                prev->next = current->next;
            }
            else{
                head = current->next;
            }
            delete current;
            return;
        }
        //Need break here to exit when list is sorted.
        if (current->data > key) {
            break;
        }
        prev = current;
        current = current->next;
    }
}
