#include "SortedVectorDict.hpp"
#include <utility>

void SortedVectorDict::insert(int key) {
    //Need to find the position to insert
    int left = 0;
    int right = data.size();
    while (left < right){
        // Finds the middle position and if the mid data is less than the key then we know we must go to the left
        int mid = left + (right - left) / 2;
        if(data[mid] < key){
            left = mid + 1;
        }
        //else go right
        else{
            right = mid;
        }
    }
    data.insert(data.begin() + left, key);
    //data.push_back(key);
}

std::size_t SortedVectorDict::lookup_idx(int key) const {
    // Performs a linear search on an unsorted container.
    // Returns index i (0 <= i < data.size() and data[i] == key); otherwise returns
    // data.size() ("not found").
    for (auto i = 0; i < data.size(); i++) {
        if (data[i] == key)
            return i;
    }
    return data.size();

}

bool SortedVectorDict::lookup(int key) const {

    auto idx = lookup_idx(key);
    return idx != data.size();
}

/*bool SortedVectorDict::lookup(int key) const {
    return false;
}*/
void SortedVectorDict::remove(int key) {
    std::size_t idx = lookup_idx(key);
    if (idx != data.size()) {
        data.erase(data.begin() + idx);
    }
}
