#pragma once
#include "Dictionary.hpp"
#include <vector>

class SortedLinkedListDict : public Dictionary {
public:
    SortedLinkedListDict();
    ~SortedLinkedListDict();
    void insert(int) override;
    bool lookup(int) const override;
    void remove(int) override;

private:
    struct Node {
        int data;
        Node* next;
    };
    Node* head;
    //std::vector<int> data;
};