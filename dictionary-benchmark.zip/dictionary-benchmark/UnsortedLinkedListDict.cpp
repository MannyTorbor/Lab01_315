#include "UnsortedLinkedListDict.hpp"
#include <cstddef>

UnsortedLinkedListDict::UnsortedLinkedListDict() : head(nullptr){}

/**
 * Destructor for UnsortedLinkedListDict.
 * Frees all allocated memory for nodes in the linked list.
 *
 * @post all nodes are deleted, memory is freed
 */
UnsortedLinkedListDict::~UnsortedLinkedListDict(){
    while (head){
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}
/**
 * Simple it just inserts a key at the beginning of the unsorted linked list.
 * @param key
 */
void UnsortedLinkedListDict::insert(int key) {
    Node*  newNode = new Node;
    newNode->data = key;
    newNode->next = head;
    head = newNode;

}

/**
 * Searches for a key in the unsorted linked list.
 * Performs linear search through all nodes.
 *
 * @param key the integer value to search for
 * @return true if key is found, false otherwise
 * @post no modification to the linked list, only search operation
 */
bool UnsortedLinkedListDict::lookup(int key) const {
    Node* current = head;
    while (current != nullptr) {
        if (current->data == key) {
            return true;
        }
        current  =  current->next;
    }
    return false;
}

/**
 * Removes the first occurrence of a key from the unsorted linked list.
 * If key is not found, the list remains unchanged.
 *
 * @param key the integer value to remove from the dictionary
 * @post if key exists, first occurrence is removed and memory freed
 *       if key doesn't exist, dictionary remains unchanged
 */
void UnsortedLinkedListDict::remove(int key) {
    Node* current = head;
    Node* prev = nullptr;

    while(current != nullptr){
        if (current->data == key) {
            if (prev != nullptr) {
                prev->next = current->next;

            }
            else{
                head = current->next;
            }
            delete current;
            return;
        }
        prev = current;
        current = current->next;
    }

}
